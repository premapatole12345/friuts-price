# Module 03 — Database Integration Blog App

A complete example using Node.js, Express.js, MongoDB, JWT, bcrypt, and a browser frontend.

## Module objectives
- Connect application to MongoDB (local or Atlas)
- Securely persist user data using bcrypt password hashing
- Save blog posts in MongoDB
- Retrieve and show all blog posts
- Display individual blog details by ID
- Frontend-to-backend API integration

## Run
1. Install Node.js 18+ and MongoDB (or create an Atlas database).
2. Open terminal inside `backend`, run `npm install`.
3. Copy `.env.example` to `.env`; set `MONGO_URI` and a strong `JWT_SECRET`.
4. Run `npm run dev` or `npm start`.
5. Serve frontend directory, e.g. `npx serve . -l 5173`.
6. Set `CLIENT_ORIGIN=http://localhost:5173` in backend `.env`; restart server.
7. Open frontend at `http://localhost:5173`.

Never upload your actual `.env` or credentials to GitHub.

## Endpoints
GET /api/health — database health
POST /api/auth/register — register (password hashed)
POST /api/auth/login — login, JWT response
GET /api/auth/me — token protected user details
GET /api/blogs — retrieve all posts
GET /api/blogs/:id — individual blog details
POST /api/blogs — authenticated create
PUT /api/blogs/:id — owner update
DELETE /api/blogs/:id — owner delete

## GitHub submission
Repository suggestion: `module-03-database-integration`. Upload project files including this README and `.env.example` only.

## LinkedIn caption
Completed Module 03 — Database Integration! Built a blog application connected to MongoDB using Node.js and Express.js. Implemented secure credential storage with bcrypt, blog post persistence, retrieval of all blogs, an individual blog details page, and frontend/backend API integration.

GitHub: [Insert repository URL]

#MongoDB #DatabaseIntegration #NodeJS #ExpressJS #RESTAPI #WebDevelopment
